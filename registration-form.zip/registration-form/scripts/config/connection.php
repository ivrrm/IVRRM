<?php

$connection = new mysqli("localhost","root","","ivrrm_market");
if (!$connection) {
    die("Error in database connection".$connection->connect_error);
}
