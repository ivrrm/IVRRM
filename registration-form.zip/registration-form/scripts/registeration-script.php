<?php
include "config/connection.php";
include_once "Classes/Common.php";

if (isset($_POST['submit'])) {
    $shopImg = '';
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $shopName = $_POST['shopName'];
    $shopAddress = $_POST['shopAddress'];
    $pincode = $_POST['pincode'];
    $paytmUpi = $_POST['paytmUpi'];
    $shopLocation = $_POST['shopLocation'];
    $state = $_POST['state'];
    $password = $_POST['password'];
    $confpassword = $_POST['confpassword'];

    if ($_FILES['image']['tmp_name']) {
        $uploadDir = "../uploads/" ;
        $shopImg = $_FILES['image']['name'];
        $imageTmpName = $_FILES['image']['tmp_name'];
        move_uploaded_file($imageTmpName,$uploadDir.$shopImg);
    }
    $common = new Common();
    $save = $common->register($connection,$firstName,$lastName,$email,$contact,$shopName,$shopAddress,$pincode,$paytmUpi,
        $shopLocation,$shopImg,$state,sha1($password));
    if ($save) {
            //echo "resgisrted !";
        echo '<script>alert("Registration successfull !");</script>';
        echo '<script>window.location.href="../"</script>';
    }

}
