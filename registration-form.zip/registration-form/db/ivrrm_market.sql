-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2019 at 01:56 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ivrrm_market`
--

-- --------------------------------------------------------

--
-- Table structure for table `iv_shops`
--

CREATE TABLE `iv_shops` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `upi` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `vendorId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iv_shops`
--

INSERT INTO `iv_shops` (`id`, `name`, `address`, `pincode`, `upi`, `location`, `state`, `image`, `vendorId`) VALUES
(3, 'Peyush traders', '40D Dayalpuram Hanspuram Naubasta Kanpur, Uttar Pradesh India', '208021', '///', 'Chandni Chowk', 'New Delhi', 'editot.jpg', 3);

-- --------------------------------------------------------

--
-- Table structure for table `iv_vendor`
--

CREATE TABLE `iv_vendor` (
  `id` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iv_vendor`
--

INSERT INTO `iv_vendor` (`id`, `firstName`, `lastName`, `email`, `contact`, `password`) VALUES
(3, 'Ankit', 'Kumar', 'cs.ankitprajapati@gmail.com', '9692852852', '40bd001563085fc35165329ea1ff5c5ecbdbbeef');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iv_shops`
--
ALTER TABLE `iv_shops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iv_vendor`
--
ALTER TABLE `iv_vendor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `iv_shops`
--
ALTER TABLE `iv_shops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `iv_vendor`
--
ALTER TABLE `iv_vendor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
