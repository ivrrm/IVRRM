function validateForm() {
   var email = $("#email").val();
   var pincode = $("#pincode").val();
   var contact = $("#contact").val();
   var password = $("#password").val();
   var confpassword = $("#confpassword").val();

   if (!validateEmail(email) && email !=""){
       alert("Please enter valid email id");
       $("#email").focus();
       return false;
   }else if (!validatePhoneNumber(contact) && contact !="") {
       alert("Please enter valid contact number");
       $("#contact").focus();
       return false;
   }else if (pincode.length !=6 && pincode !="") {
       alert("Please enter valid pincode");
       $("#pincode").focus();
       return false;
   }else if (password != confpassword && (password !="" && confpassword !="" )) {
       alert("Password and confirm password are not same");
       $("#confpassword").focus();
       return false;
   }else{
       return  true;
   }
}




/*========================================================================================
                                    VALIDATION CODE
     ========================================================================================*/

function validateEmail(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.match(mailformat)) {
        return true;
    } else{
        return false;
    }
}

function validatePhoneNumber(inputtxt) {
    var phonenoPattern = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
    if( inputtxt.match(phonenoPattern) ) {
        return true;
    }
    else {
        return false;
    }
}
